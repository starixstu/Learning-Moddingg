package stu.learning;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {

    // The Item ID is "trustping". This line creates the actual item object.
    public static final Item TRUSTPING = registerItem("trustping", new Item(new Item.Settings()));

    // This helper method handles the "Address" of the item
    private static Item registerItem(String name, Item item) {
        // Identifier.of("MOD_ID", "ITEM_NAME") is the crucial fix for 1.21.4
        return Registry.register(Registries.ITEM, Identifier.of("learningmod", name), item);
    }

    public static void registerModItems() {
        LearningMod.LOGGER.info("Registering Mod Items for " + LearningMod.MOD_ID);

        // This adds your item to the 'Ingredients' tab in the creative menu
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> {
            entries.add(TRUSTPING); 
        });
    }
}
